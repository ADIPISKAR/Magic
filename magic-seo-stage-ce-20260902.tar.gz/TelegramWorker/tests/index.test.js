import assert from 'node:assert/strict';
import test from 'node:test';

import worker from '../src/index.js';

const request = () => new Request('https://worker.test/api/leads', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-Bot-Api-Secret': 'shared-secret',
  },
  body: JSON.stringify({ name: 'Иван', phone: '+7 900 000-00-00' }),
});

test('routes a lead to the configured group topic', async () => {
  const originalFetch = globalThis.fetch;
  let telegramRequest;
  globalThis.fetch = async (url, options) => {
    telegramRequest = { url, options };
    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const response = await worker.fetch(request(), {
      BOT_API_SECRET: 'shared-secret',
      TELEGRAM_BOT_TOKEN: 'bot-token',
      TELEGRAM_GROUP_CHAT_ID: '-1001234567890',
      TELEGRAM_LEADS_THREAD_ID: '42',
    });

    assert.equal(response.status, 202);
    const body = new URLSearchParams(telegramRequest.options.body);
    assert.equal(body.get('chat_id'), '-1001234567890');
    assert.equal(body.get('message_thread_id'), '42');
    assert.match(body.get('text'), /Новая заявка/);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('does not fall back to the legacy destination', async () => {
  const response = await worker.fetch(request(), {
    BOT_API_SECRET: 'shared-secret',
    TELEGRAM_BOT_TOKEN: 'bot-token',
    TELEGRAM_CHAT_ID: '-1009999999999',
  });

  assert.equal(response.status, 500);
  assert.deepEqual(await response.json(), { message: 'Bot configuration error.' });
});

test('routes an SEO event only to the configured SEO topic', async () => {
  const originalFetch = globalThis.fetch;
  let telegramRequest;
  globalThis.fetch = async (url, options) => {
    telegramRequest = { url, options };
    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const response = await worker.fetch(new Request('https://worker.test/api/seo-notifications', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Bot-Api-Secret': 'seo-secret',
      },
      body: JSON.stringify({ kind: 'weekly', message: 'Проверка отчёта' }),
    }), {
      SEO_API_SECRET: 'seo-secret',
      TELEGRAM_BOT_TOKEN: 'bot-token',
      TELEGRAM_GROUP_CHAT_ID: '-1001234567890',
      TELEGRAM_SEO_THREAD_ID: '84',
    });

    assert.equal(response.status, 202);
    const body = new URLSearchParams(telegramRequest.options.body);
    assert.equal(body.get('chat_id'), '-1001234567890');
    assert.equal(body.get('message_thread_id'), '84');
    assert.match(body.get('text'), /Еженедельный SEO-отчёт/);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('serves the private SEO menu through the protected backend', async () => {
  const originalFetch = globalThis.fetch;
  const calls = [];
  globalThis.fetch = async (url, options) => {
    calls.push({ url: String(url), options });
    if (String(url) === 'https://magiarnd.ru/api/seo/telegram') {
      assert.equal(options.headers['X-SEO-Backend-Secret'], 'backend-secret');
      assert.deepEqual(JSON.parse(options.body), { action: 'menu', requested_by: 123 });
      return new Response(JSON.stringify({
        text: 'SEO menu',
        keyboard: [[{ text: '7 дней', callback_data: 'seo:period:7' }]],
      }), { status: 200, headers: { 'Content-Type': 'application/json' } });
    }
    return new Response(JSON.stringify({ ok: true, result: {} }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const response = await worker.fetch(new Request('https://worker.test/telegram/webhook', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Telegram-Bot-Api-Secret-Token': 'webhook-secret',
      },
      body: JSON.stringify({
        message: {
          from: { id: 123 },
          chat: { id: 123, type: 'private' },
          text: '/start',
        },
      }),
    }), {
      TELEGRAM_WEBHOOK_SECRET: 'webhook-secret',
      TELEGRAM_BOT_TOKEN: 'bot-token',
      TELEGRAM_ALLOWED_USERS: '123,456',
      SEO_BACKEND_URL: 'https://magiarnd.ru',
      SEO_BACKEND_SECRET: 'backend-secret',
    });

    assert.equal(response.status, 200);
    const telegram = calls.find((call) => call.url.endsWith('/sendMessage'));
    assert.ok(telegram);
    const body = JSON.parse(telegram.options.body);
    assert.equal(body.chat_id, 123);
    assert.equal(body.text, 'SEO menu');
    assert.deepEqual(body.reply_markup.inline_keyboard[0][0], {
      text: '7 дней', callback_data: 'seo:period:7',
    });
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('rejects Telegram webhook calls without the configured secret', async () => {
  const response = await worker.fetch(new Request('https://worker.test/telegram/webhook', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({}),
  }), {
    TELEGRAM_WEBHOOK_SECRET: 'webhook-secret',
    TELEGRAM_BOT_TOKEN: 'bot-token',
    SEO_BACKEND_URL: 'https://magiarnd.ru',
    SEO_BACKEND_SECRET: 'backend-secret',
  });

  assert.equal(response.status, 401);
});
