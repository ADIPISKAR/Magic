<?php

declare(strict_types=1);

namespace Tests\Feature;

use Illuminate\Support\Facades\Config;
use Tests\TestCase;

final class SeoTelegramTest extends TestCase
{
    private string $dashboard;

    protected function setUp(): void
    {
        parent::setUp();
        $this->dashboard = tempnam(sys_get_temp_dir(), 'seo-dashboard-');
        file_put_contents($this->dashboard, json_encode([
            'anchor_date' => '2026-09-02',
            'source_labels' => [
                'topvisor' => 'готово',
                'yandex_webmaster' => 'не настроено',
                'yandex_metrika' => 'не настроено',
            ],
            'keywords' => [[
                'keyword_id' => 1,
                'keyword' => 'ремонт квартир ростов-на-дону',
                'status' => 'not_found',
                'position' => null,
                'frequency' => 53,
            ]],
            'keyword_histories' => ['1' => [
                'keyword' => 'ремонт квартир ростов-на-дону',
                'current' => ['position' => null, 'found_url' => null],
                'periods' => ['3' => null, '7' => null, '30' => null],
            ]],
            'periods' => [
                '3' => ['telegram_text' => 'Отчёт 3 дня'],
                '7' => [
                    'telegram_text' => 'Отчёт 7 дней',
                    'positions' => ['best_growth' => [], 'worst_drop' => []],
                    'webmaster' => ['shows' => null, 'clicks' => null, 'ctr' => null, 'new_queries' => []],
                    'metrika' => ['visits' => null, 'users' => null, 'goal_reaches' => null, 'messenger_reaches' => null],
                ],
                '30' => ['telegram_text' => 'Отчёт 30 дней'],
            ],
            'charts' => [],
        ], JSON_UNESCAPED_UNICODE));
        Config::set('services.seo_backend.secret', 'test-secret');
        Config::set('services.seo_backend.dashboard_path', $this->dashboard);
    }

    protected function tearDown(): void
    {
        @unlink($this->dashboard);
        parent::tearDown();
    }

    public function test_backend_requires_its_secret(): void
    {
        $this->postJson('/api/seo/telegram', ['action' => 'menu'])->assertUnauthorized();
    }

    public function test_menu_reports_source_availability_without_fake_zeroes(): void
    {
        $this->withHeader('X-SEO-Backend-Secret', 'test-secret')
            ->postJson('/api/seo/telegram', ['action' => 'menu'])
            ->assertOk()
            ->assertJsonPath('text', "🔎 SEO-мониторинг\n\nКонтрольные позиции: Topvisor — готово\nПоисковая аналитика: Webmaster — не настроено\nОрганика и конверсии: Metrika — не настроено\n\nДата позиции: 2026-09-02");
    }

    public function test_period_returns_prepared_combined_report(): void
    {
        $this->withHeader('X-SEO-Backend-Secret', 'test-secret')
            ->postJson('/api/seo/telegram', ['action' => 'period:7'])
            ->assertOk()
            ->assertJsonPath('text', 'Отчёт 7 дней');
    }
}
