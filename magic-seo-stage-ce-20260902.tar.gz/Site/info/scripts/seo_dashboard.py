"""Build the combined Topvisor → Webmaster → Metrika SEO dashboard."""
from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import os
import sqlite3
import sys
import tempfile
import urllib.parse
from collections import defaultdict
from pathlib import Path
from typing import Iterable, Sequence

from seo_common import SeoError
from seo_positions import (
    build_summary,
    format_telegram_report,
    keyword_history,
    parse_time,
)
from seo_sources import AnalyticsStore, iso_time, load_source_config, normalize_query


def _sum_known(values: Iterable[float | None]) -> float | None:
    known = [value for value in values if value is not None]
    return None if not known else sum(known)


def _average_known(values: Iterable[float | None]) -> float | None:
    known = [value for value in values if value is not None]
    return None if not known else round(sum(known) / len(known), 4)


def _weighted_position(rows: Sequence[dict], field: str) -> float | None:
    weighted = [
        (row[field], row['shows']) for row in rows
        if row.get(field) is not None and row.get('shows') not in (None, 0)
    ]
    if weighted:
        denominator = sum(weight for _, weight in weighted)
        return round(sum(value * weight for value, weight in weighted) / denominator, 4)
    return _average_known(row.get(field) for row in rows)


def _period_bounds(anchor: dt.date, days: int) -> tuple[str, str]:
    return (anchor - dt.timedelta(days=max(days - 1, 0))).isoformat(), anchor.isoformat()


def _dedupe_latest(rows: Sequence[sqlite3.Row], key_fields: Sequence[str]) -> list[dict]:
    result = {}
    for raw in sorted(rows, key=lambda row: (row['fetched_at'], row['id'])):
        row = dict(raw)
        result[tuple(row[field] for field in key_fields)] = row
    return list(result.values())


def source_statuses(store: AnalyticsStore) -> dict:
    with store.session() as connection:
        rows = connection.execute(
            """SELECT r.* FROM seo_source_runs r
               JOIN (
                   SELECT source, MAX(finished_at) AS finished_at
                   FROM seo_source_runs GROUP BY source
               ) latest ON latest.source = r.source AND latest.finished_at = r.finished_at
               ORDER BY r.run_id""",
        ).fetchall()
    return {row['source']: dict(row) for row in rows}


def webmaster_period(store: AnalyticsStore, anchor: dt.date, days: int) -> dict:
    date1, date2 = _period_bounds(anchor, days)
    with store.session() as connection:
        rows = connection.execute(
            """SELECT * FROM seo_webmaster_queries
               WHERE period_start >= ? AND period_end <= ?
               ORDER BY fetched_at, id""",
            (date1, date2),
        ).fetchall()
    rows = _dedupe_latest(rows, ('period_start', 'period_end', 'query_id', 'device'))
    grouped = defaultdict(list)
    for row in rows:
        grouped[normalize_query(row['query_text'])].append(row)
    queries = []
    for group in grouped.values():
        sample = group[-1]
        shows = _sum_known(row.get('shows') for row in group)
        clicks = _sum_known(row.get('clicks') for row in group)
        ctr = None if shows in (None, 0) or clicks is None else round(clicks / shows * 100, 4)
        queries.append({
            'query_id': sample['query_id'],
            'query_text': sample['query_text'],
            'shows': shows,
            'clicks': clicks,
            'ctr': ctr,
            'avg_show_position': _weighted_position(group, 'avg_show_position'),
            'avg_click_position': _weighted_position(group, 'avg_click_position'),
            'is_target': bool(sample['is_target']),
            'target_keyword_id': sample['target_keyword_id'],
        })
    queries.sort(key=lambda row: (-(row['shows'] if row['shows'] is not None else -1), row['query_text']))
    return {
        'period_start': date1,
        'period_end': date2,
        'query_count': len(queries) if rows else None,
        'shows': _sum_known(row['shows'] for row in queries),
        'clicks': _sum_known(row['clicks'] for row in queries),
        'ctr': (
            None if _sum_known(row['shows'] for row in queries) in (None, 0)
            or _sum_known(row['clicks'] for row in queries) is None
            else round(
                _sum_known(row['clicks'] for row in queries)
                / _sum_known(row['shows'] for row in queries) * 100,
                4,
            )
        ),
        'queries': queries,
        'new_queries': [row for row in queries if not row['is_target']],
    }


def _landing_path(value: str | None) -> str | None:
    if not value:
        return None
    parsed = urllib.parse.urlsplit(value)
    path = parsed.path if parsed.scheme or parsed.netloc else value.split('?', 1)[0]
    path = '/' + path.lstrip('/')
    return path.rstrip('/') or '/'


def metrika_period(store: AnalyticsStore, anchor: dt.date, days: int) -> dict:
    date1, date2 = _period_bounds(anchor, days)
    with store.session() as connection:
        traffic_rows = connection.execute(
            """SELECT * FROM seo_metrika_landings
               WHERE period_start >= ? AND period_end <= ?
               ORDER BY fetched_at, id""",
            (date1, date2),
        ).fetchall()
        goal_rows = connection.execute(
            """SELECT * FROM seo_metrika_goals
               WHERE period_start >= ? AND period_end <= ?
               ORDER BY fetched_at, id""",
            (date1, date2),
        ).fetchall()
    traffic_rows = _dedupe_latest(
        traffic_rows, ('period_start', 'period_end', 'landing_page', 'search_engine'),
    )
    goal_rows = _dedupe_latest(
        goal_rows, ('period_start', 'period_end', 'landing_page', 'search_engine', 'goal_id'),
    )
    landings = defaultdict(list)
    for row in traffic_rows:
        path = _landing_path(row['landing_page'])
        if path:
            landings[path].append(row)
    goals_by_landing = defaultdict(list)
    for row in goal_rows:
        path = _landing_path(row['landing_page'])
        if path:
            goals_by_landing[path].append(row)
    items = []
    for path in sorted(set(landings) | set(goals_by_landing)):
        traffic = landings.get(path, [])
        goals_grouped = defaultdict(list)
        for row in goals_by_landing.get(path, []):
            goals_grouped[row['goal_id']].append(row)
        goal_items = []
        for goal_id, rows in goals_grouped.items():
            sample = rows[-1]
            reaches = _sum_known(row.get('reaches') for row in rows)
            visits = _sum_known(row.get('visits') for row in traffic)
            goal_items.append({
                'goal_id': goal_id,
                'goal_name': sample.get('goal_name'),
                'goal_type': sample.get('goal_type'),
                'reaches': reaches,
                'conversion_rate': (
                    None if visits in (None, 0) or reaches is None
                    else round(reaches / visits * 100, 4)
                ),
                'attribution_level': 'landing_page',
            })
        items.append({
            'landing_page': path,
            'visits': _sum_known(row.get('visits') for row in traffic),
            'users': _sum_known(row.get('users') for row in traffic),
            'bounce_rate': _average_known(row.get('bounce_rate') for row in traffic),
            'goals': sorted(goal_items, key=lambda item: item['goal_id']),
        })
    items.sort(key=lambda row: (-(row['visits'] if row['visits'] is not None else -1), row['landing_page']))
    goal_reaches = _sum_known(
        goal['reaches'] for landing in items for goal in landing['goals']
    )
    messenger_reaches = _sum_known(
        goal['reaches'] for landing in items for goal in landing['goals']
        if (goal.get('goal_type') or '').casefold() == 'messenger'
    )
    return {
        'period_start': date1,
        'period_end': date2,
        'visits': _sum_known(item['visits'] for item in items),
        'users': _sum_known(item['users'] for item in items),
        'goal_reaches': goal_reaches,
        'messenger_reaches': messenger_reaches,
        'landings': items,
    }


def _current_anchor(store: AnalyticsStore) -> dt.date:
    rows = store.latest_snapshot()
    checks = [parse_time(row['checked_at']).date() for row in rows if row.get('checked_at')]
    return max(checks) if checks else dt.datetime.now(dt.timezone.utc).date()


def merge_keyword_analytics(position_rows: Sequence[dict], webmaster: dict, metrika: dict) -> list[dict]:
    webmaster_by_query = {normalize_query(row['query_text']): row for row in webmaster['queries']}
    metrika_by_landing = {row['landing_page']: row for row in metrika['landings']}
    merged = []
    for row in position_rows:
        query = webmaster_by_query.get(normalize_query(row['keyword']))
        landing = _landing_path(row.get('found_url'))
        landing_analytics = metrika_by_landing.get(landing) if landing else None
        merged.append({
            'keyword_id': row['keyword_id'],
            'keyword': row['keyword'],
            'category': row['category'],
            'position': row.get('position'),
            'position_status': row.get('status'),
            'frequency': row.get('frequency'),
            'found_url': row.get('found_url'),
            'webmaster': query,
            'landing_page': landing,
            # Conversions remain attached to the landing page, never to the query.
            'landing_analytics': landing_analytics,
            'conversion_attribution': 'landing_page' if landing_analytics else None,
        })
    return merged


def _status_label(status: dict | None) -> str:
    if not status:
        return 'нет данных'
    return {
        'ok': 'готово', 'not_configured': 'не настроено', 'error': 'ошибка',
    }.get(status.get('status'), 'нет данных')


def _metric(value, suffix: str = '') -> str:
    if value is None:
        return 'нет данных'
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    return f'{value}{suffix}'


def format_combined_period(position_summary: dict, webmaster: dict, metrika: dict) -> str:
    text = format_telegram_report(position_summary)
    lines = [text, '', '🔍 Яндекс Вебмастер']
    if webmaster['query_count'] is None:
        lines.append('Данных за период нет.')
    else:
        lines.extend([
            f"Запросов: {webmaster['query_count']}",
            f"Показы: {_metric(webmaster['shows'])}",
            f"Клики: {_metric(webmaster['clicks'])}",
            f"CTR: {_metric(webmaster['ctr'], '%')}",
            f"Новых запросов вне семантики: {len(webmaster['new_queries'])}",
        ])
    lines.extend(['', '📊 Яндекс Метрика'])
    if metrika['visits'] is None:
        lines.append('Органический трафик за период: нет данных.')
    else:
        lines.extend([
            f"Органические визиты: {_metric(metrika['visits'])}",
            f"Пользователи: {_metric(metrika['users'])}",
            f"Достижения целей: {_metric(metrika['goal_reaches'])}",
            f"Переходы в мессенджеры: {_metric(metrika['messenger_reaches'])}",
        ])
    return '\n'.join(lines)


def position_series(store: AnalyticsStore, days: int, keyword_id: int | None = None) -> list[dict]:
    anchor = _current_anchor(store)
    date1, date2 = _period_bounds(anchor, days)
    with store.session() as connection:
        parameters: list[object] = [date1, date2]
        predicate = ''
        if keyword_id is not None:
            predicate = ' AND c.keyword_id = ?'
            parameters.append(keyword_id)
        rows = connection.execute(
            f"""SELECT c.keyword_id, k.keyword, substr(c.checked_at, 1, 10) AS day,
                       c.position, c.status
                FROM seo_position_checks c
                JOIN seo_keywords k ON k.id = c.keyword_id
                WHERE substr(c.checked_at, 1, 10) BETWEEN ? AND ?
                  AND c.source = 'topvisor' {predicate}
                ORDER BY day, c.keyword_id, c.id""",
            parameters,
        ).fetchall()
    latest = {}
    for row in rows:
        latest[(row['day'], row['keyword_id'])] = dict(row)
    by_day = defaultdict(list)
    for row in latest.values():
        by_day[row['day']].append(row)
    result = []
    start = dt.date.fromisoformat(date1)
    end = dt.date.fromisoformat(date2)
    day = start
    while day <= end:
        values = by_day.get(day.isoformat(), [])
        found = [row['position'] for row in values if row['status'] == 'found']
        result.append({
            'date': day.isoformat(),
            'average_position': None if not found else round(sum(found) / len(found), 2),
            'top10': None if not values else sum(
                row['status'] == 'found' and row['position'] <= 10 for row in values
            ),
            'position': (
                values[-1]['position'] if keyword_id is not None and values
                and values[-1]['status'] == 'found' else None
            ),
        })
        day += dt.timedelta(days=1)
    return result


def _plot_series(series: Sequence[dict], field: str, title: str, path: Path, invert: bool = False) -> None:
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import matplotlib.dates as mdates
    except ImportError as error:
        raise SeoError('matplotlib is required to generate SEO charts.') from error
    dates = [dt.date.fromisoformat(row['date']) for row in series]
    values = [math.nan if row[field] is None else row[field] for row in series]
    path.parent.mkdir(parents=True, exist_ok=True)
    figure, axis = plt.subplots(figsize=(10, 5.2), dpi=140)
    axis.plot(dates, values, marker='o', linewidth=2, color='#2563eb')
    axis.set_title(title)
    axis.grid(True, alpha=.25)
    axis.xaxis.set_major_formatter(mdates.DateFormatter('%d.%m'))
    axis.xaxis.set_major_locator(mdates.AutoDateLocator(minticks=2, maxticks=8))
    if invert:
        axis.invert_yaxis()
        axis.set_ylabel('Позиция (1 — лучше)')
    else:
        axis.set_ylabel('Количество запросов')
        axis.set_ylim(bottom=0)
    figure.autofmt_xdate()
    figure.tight_layout()
    figure.savefig(path, format='png')
    plt.close(figure)


def generate_charts(store: AnalyticsStore, charts_path: str | Path) -> dict:
    target = Path(charts_path)
    result = {}
    for days in (7, 30, 90):
        path = target / f'average-position-{days}d.png'
        _plot_series(
            position_series(store, days), 'average_position',
            f'Средняя позиция Topvisor — {days} дней', path, invert=True,
        )
        result[f'average_position_{days}d'] = str(path)
    top10 = target / 'top10-count-30d.png'
    _plot_series(
        position_series(store, 30), 'top10',
        'Количество запросов в TOP-10 — 30 дней', top10,
    )
    result['top10_count_30d'] = str(top10)
    return result


def build_dashboard(config: dict, store: AnalyticsStore, *, with_charts: bool = True) -> dict:
    store.initialize()
    anchor = _current_anchor(store)
    position_rows = store.latest_snapshot()
    statuses = source_statuses(store)
    periods = {}
    for days in (1, 3, 7, 30):
        positions = build_summary(store, days, config['positions'])
        webmaster = webmaster_period(store, anchor, days)
        metrika = metrika_period(store, anchor, days)
        periods[str(days)] = {
            'positions': positions,
            'webmaster': webmaster,
            'metrika': metrika,
            'merged_keywords': merge_keyword_analytics(position_rows, webmaster, metrika),
            'telegram_text': format_combined_period(positions, webmaster, metrika),
        }
    histories = {
        str(row['keyword_id']): keyword_history(store, row['keyword'], config['positions'])
        for row in position_rows
    }
    charts = {}
    chart_error = None
    if with_charts:
        try:
            charts = generate_charts(store, config['charts_path'])
        except SeoError as error:
            chart_error = str(error)
    dashboard = {
        'generated_at': iso_time(),
        'anchor_date': anchor.isoformat(),
        'position_source': 'topvisor',
        'search_api_reserve_enabled': bool(
            (config['positions'].get('yandex_search_api') or {}).get('enabled')
        ),
        'sources': statuses,
        'source_labels': {name: _status_label(status) for name, status in statuses.items()},
        'keywords': position_rows,
        'keyword_histories': histories,
        'periods': periods,
        'charts': charts,
        'chart_error': chart_error,
    }
    return dashboard


def write_dashboard(config: dict, dashboard: dict) -> Path:
    path = Path(config['dashboard_path'])
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(dashboard, ensure_ascii=False, indent=2).encode('utf-8')
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as handle:
        handle.write(payload)
        temporary = Path(handle.name)
    os.replace(temporary, path)
    try:
        path.chmod(0o600)
    except OSError:
        pass
    return path


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest='command', required=True)
    build = subparsers.add_parser('build')
    build.add_argument('--no-charts', action='store_true')
    report = subparsers.add_parser('report')
    report.add_argument('--days', choices=(1, 3, 7, 30), type=int, default=7)
    args = parser.parse_args(argv)
    try:
        config = load_source_config()
        store = AnalyticsStore(config['database_path'])
        dashboard = build_dashboard(config, store, with_charts=not getattr(args, 'no_charts', False))
        if args.command == 'report':
            print(dashboard['periods'][str(args.days)]['telegram_text'])
        else:
            path = write_dashboard(config, dashboard)
            print(f'Wrote SEO dashboard: {path}')
            if dashboard['chart_error']:
                print('Charts unavailable: ' + dashboard['chart_error'], file=sys.stderr)
        return 0
    except (SeoError, OSError, sqlite3.Error, ValueError) as error:
        print(f'SEO DASHBOARD FAILED: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
