const MAX_BODY_BYTES = 16 * 1024;
const SEO_EVENT_TITLES = {
  daily: 'Ежедневный SEO-отчёт',
  weekly: 'Еженедельный SEO-отчёт',
  position_change: 'Изменение позиций',
  top10_entry: 'Вход в TOP-10',
  top10_exit: 'Выход из TOP-10',
  strong_growth: 'Сильный рост',
  strong_drop: 'Сильное падение',
  metrika: 'Яндекс Метрика',
  wordstat: 'Wordstat',
  service_error: 'Ошибка SEO-сервиса',
  manual_check: 'Ручная SEO-проверка',
  other: 'SEO-уведомление',
  test: 'Проверка SEO-уведомлений',
};

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === 'GET' && url.pathname === '/health') {
      return jsonResponse({ status: 'ok' });
    }

    if (request.method === 'POST' && url.pathname === '/api/seo-notifications') {
      return handleSeoNotification(request, env);
    }

    if (request.method === 'POST' && url.pathname === '/telegram/webhook') {
      return handleTelegramWebhook(request, env);
    }

    if (request.method !== 'POST' || url.pathname !== '/api/leads') {
      return jsonResponse({ message: 'Not found' }, 404);
    }

    const groupChatId = normalizeIdentifier(env.TELEGRAM_GROUP_CHAT_ID);
    const leadsThreadId = normalizeThreadId(env.TELEGRAM_LEADS_THREAD_ID);
    if (!env.BOT_API_SECRET || !env.TELEGRAM_BOT_TOKEN || !groupChatId || !leadsThreadId) {
      return jsonResponse({ message: 'Bot configuration error.' }, 500);
    }

    const providedSecret = request.headers.get('X-Bot-Api-Secret') ?? '';
    if (!(await secretsMatch(env.BOT_API_SECRET, providedSecret))) {
      return jsonResponse({ message: 'Unauthorized' }, 401);
    }

    const contentLength = Number(request.headers.get('Content-Length') ?? '0');
    if (Number.isFinite(contentLength) && contentLength > MAX_BODY_BYTES) {
      return jsonResponse({ message: 'Request body is too large.' }, 413);
    }

    let payload;
    try {
      const body = await request.text();
      if (new TextEncoder().encode(body).byteLength > MAX_BODY_BYTES) {
        return jsonResponse({ message: 'Request body is too large.' }, 413);
      }
      payload = JSON.parse(body);
    } catch {
      return jsonResponse({ message: 'Invalid JSON body.' }, 400);
    }

    const name = normalizeField(payload?.name, 100);
    const phone = normalizeField(payload?.phone, 40);
    if (!name || !phone) {
      return jsonResponse({ message: 'Name and phone are required.' }, 422);
    }

    const lines = [
      '📩 Новая заявка',
      '',
      `👤 Имя: ${escapeHtml(name)}`,
      `📞 Телефон: ${escapeHtml(phone)}`,
    ];

    for (const field of ['message', 'source']) {
      const value = normalizeField(payload?.[field], 1000);
      if (value) {
        lines.push(`${escapeHtml(field)}: ${escapeHtml(value)}`);
      }
    }

    const telegramResponse = await fetch(
      `https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          chat_id: groupChatId,
          message_thread_id: leadsThreadId,
          text: lines.join('\n'),
          parse_mode: 'HTML',
        }),
      },
    );

    let telegramResult;
    try {
      telegramResult = await telegramResponse.json();
    } catch {
      telegramResult = null;
    }

    if (!telegramResponse.ok || !telegramResult?.ok) {
      return jsonResponse({ message: 'Unable to deliver lead.' }, 502);
    }

    return jsonResponse({ message: 'Lead accepted.' }, 202);
  },
};

async function handleTelegramWebhook(request, env) {
  if (!env.TELEGRAM_WEBHOOK_SECRET
      || !env.TELEGRAM_BOT_TOKEN
      || !env.SEO_BACKEND_URL
      || !env.SEO_BACKEND_SECRET) {
    return jsonResponse({ message: 'Bot configuration error.' }, 500);
  }
  const providedSecret = request.headers.get('X-Telegram-Bot-Api-Secret-Token') ?? '';
  if (!(await secretsMatch(env.TELEGRAM_WEBHOOK_SECRET, providedSecret))) {
    return jsonResponse({ message: 'Unauthorized' }, 401);
  }
  let update;
  try {
    update = await request.json();
  } catch {
    return jsonResponse({ message: 'Invalid JSON body.' }, 400);
  }
  const callback = update?.callback_query;
  const message = callback?.message ?? update?.message;
  const userId = Number(callback?.from?.id ?? message?.from?.id);
  const chatId = Number(message?.chat?.id);
  const allowedUsers = parseAllowedUsers(env.TELEGRAM_ALLOWED_USERS ?? '');
  if (!Number.isInteger(userId) || !allowedUsers.has(userId)
      || !Number.isInteger(chatId) || message?.chat?.type !== 'private') {
    if (callback?.id) {
      await telegramMethod(env, 'answerCallbackQuery', {
        callback_query_id: callback.id,
        text: 'Нет доступа.',
        show_alert: false,
      });
    }
    return jsonResponse({ message: 'Ignored.' }, 200);
  }
  const rawAction = typeof callback?.data === 'string' && callback.data.startsWith('seo:')
    ? callback.data.slice(4)
    : 'menu';
  const text = normalizeField(message?.text, 100);
  const action = callback ? rawAction : (text === '/start' || text === '🔎 Позиции' ? 'menu' : 'menu');

  if (callback?.id) {
    await telegramMethod(env, 'answerCallbackQuery', { callback_query_id: callback.id });
  }

  let backendResponse;
  try {
    backendResponse = await fetch(env.SEO_BACKEND_URL.replace(/\/$/, '') + '/api/seo/telegram', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-SEO-Backend-Secret': env.SEO_BACKEND_SECRET,
      },
      body: JSON.stringify({ action, requested_by: userId }),
    });
  } catch {
    await sendPrivateText(env, chatId, 'SEO-сервис временно недоступен.', null);
    return jsonResponse({ message: 'SEO backend unavailable.' }, 502);
  }
  let payload;
  try {
    payload = await backendResponse.json();
  } catch {
    payload = null;
  }
  if (!backendResponse.ok || !payload?.text) {
    await sendPrivateText(env, chatId, 'Не удалось получить SEO-отчёт.', null);
    return jsonResponse({ message: 'SEO backend rejected the request.' }, 502);
  }

  const replyMarkup = Array.isArray(payload.keyboard)
    ? { inline_keyboard: payload.keyboard }
    : undefined;
  if (payload.photo_base64) {
    await sendPrivatePhoto(env, chatId, payload, replyMarkup);
  } else if (callback?.message?.message_id) {
    await telegramMethod(env, 'editMessageText', {
      chat_id: chatId,
      message_id: callback.message.message_id,
      text: String(payload.text).slice(0, 3900),
      disable_web_page_preview: true,
      ...(replyMarkup ? { reply_markup: replyMarkup } : {}),
    });
  } else {
    await sendPrivateText(env, chatId, payload.text, replyMarkup);
  }
  return jsonResponse({ message: 'Telegram SEO action accepted.' }, 200);
}

function parseAllowedUsers(value) {
  const users = new Set();
  for (const item of String(value).split(/[\s,]+/).filter(Boolean)) {
    if (/^\d+$/.test(item) && Number(item) > 0) users.add(Number(item));
  }
  return users;
}

async function telegramMethod(env, method, payload) {
  const response = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  let result;
  try {
    result = await response.json();
  } catch {
    result = null;
  }
  if (!response.ok || !result?.ok) {
    throw new Error(`Telegram ${method} failed`);
  }
  return result.result;
}

async function sendPrivateText(env, chatId, text, replyMarkup) {
  return telegramMethod(env, 'sendMessage', {
    chat_id: chatId,
    text: String(text).slice(0, 3900),
    disable_web_page_preview: true,
    ...(replyMarkup ? { reply_markup: replyMarkup } : {}),
  });
}

async function sendPrivatePhoto(env, chatId, payload, replyMarkup) {
  const binary = Uint8Array.from(atob(payload.photo_base64), (character) => character.charCodeAt(0));
  const form = new FormData();
  form.append('chat_id', String(chatId));
  form.append('caption', String(payload.text).slice(0, 900));
  form.append('photo', new Blob([binary], { type: 'image/png' }), payload.photo_filename || 'seo-chart.png');
  if (replyMarkup) form.append('reply_markup', JSON.stringify(replyMarkup));
  const response = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendPhoto`, {
    method: 'POST',
    body: form,
  });
  const result = await response.json().catch(() => null);
  if (!response.ok || !result?.ok) throw new Error('Telegram sendPhoto failed');
  return result.result;
}

async function handleSeoNotification(request, env) {
  const groupChatId = normalizeIdentifier(env.TELEGRAM_GROUP_CHAT_ID);
  const seoThreadId = normalizeThreadId(env.TELEGRAM_SEO_THREAD_ID);
  if (!env.SEO_API_SECRET || !env.TELEGRAM_BOT_TOKEN || !groupChatId || !seoThreadId) {
    return jsonResponse({ message: 'Bot configuration error.' }, 500);
  }

  const providedSecret = request.headers.get('X-Bot-Api-Secret') ?? '';
  if (!(await secretsMatch(env.SEO_API_SECRET, providedSecret))) {
    return jsonResponse({ message: 'Unauthorized' }, 401);
  }

  const contentLength = Number(request.headers.get('Content-Length') ?? '0');
  if (Number.isFinite(contentLength) && contentLength > MAX_BODY_BYTES) {
    return jsonResponse({ message: 'Request body is too large.' }, 413);
  }

  let payload;
  try {
    const body = await request.text();
    if (new TextEncoder().encode(body).byteLength > MAX_BODY_BYTES) {
      return jsonResponse({ message: 'Request body is too large.' }, 413);
    }
    payload = JSON.parse(body);
  } catch {
    return jsonResponse({ message: 'Invalid JSON body.' }, 400);
  }

  const kind = normalizeField(payload?.kind, 40);
  const message = normalizeField(payload?.message, 3200);
  const title = SEO_EVENT_TITLES[kind];
  if (!title || !message) {
    return jsonResponse({ message: 'A valid kind and message are required.' }, 422);
  }

  const telegramResponse = await fetch(
    `https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        chat_id: groupChatId,
        message_thread_id: seoThreadId,
        text: `<b>${escapeHtml(title)}</b>\n\n${escapeHtml(message)}`,
        parse_mode: 'HTML',
        disable_web_page_preview: 'true',
      }),
    },
  );
  let telegramResult;
  try {
    telegramResult = await telegramResponse.json();
  } catch {
    telegramResult = null;
  }
  return telegramResponse.ok && telegramResult?.ok
    ? jsonResponse({ message: 'SEO notification accepted.' }, 202)
    : jsonResponse({ message: 'Unable to deliver SEO notification.' }, 502);
}

function normalizeIdentifier(value) {
  return typeof value === 'string' && /^-?\d+$/.test(value.trim()) ? value.trim() : '';
}

function normalizeThreadId(value) {
  const identifier = normalizeIdentifier(value);
  return identifier && Number(identifier) > 0 ? identifier : '';
}

function normalizeField(value, maxLength) {
  return typeof value === 'string' ? value.trim().slice(0, maxLength) : '';
}

function escapeHtml(value) {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

async function secretsMatch(expected, provided) {
  if (!expected || !provided) {
    return false;
  }

  const encoder = new TextEncoder();
  const [expectedHash, providedHash] = await Promise.all([
    crypto.subtle.digest('SHA-256', encoder.encode(expected)),
    crypto.subtle.digest('SHA-256', encoder.encode(provided)),
  ]);

  const expectedBytes = new Uint8Array(expectedHash);
  const providedBytes = new Uint8Array(providedHash);
  let difference = 0;
  for (let index = 0; index < expectedBytes.length; index += 1) {
    difference |= expectedBytes[index] ^ providedBytes[index];
  }

  return difference === 0;
}

function jsonResponse(payload, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
    },
  });
}
