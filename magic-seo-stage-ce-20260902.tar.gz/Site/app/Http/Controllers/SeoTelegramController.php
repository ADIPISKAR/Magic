<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class SeoTelegramController extends Controller
{
    public function show(Request $request): JsonResponse
    {
        $expected = (string) config('services.seo_backend.secret', '');
        $provided = (string) $request->header('X-SEO-Backend-Secret', '');
        if ($expected === '' || ! hash_equals($expected, $provided)) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        $dashboard = $this->readDashboard((string) config('services.seo_backend.dashboard_path', ''));
        if ($dashboard === null) {
            return response()->json([
                'message' => 'SEO dashboard is not available yet.',
                'text' => 'SEO-данные пока не подготовлены.',
                'keyboard' => $this->mainKeyboard(),
            ], 503);
        }

        $result = $this->responseFor($dashboard, trim((string) $request->input('action', 'menu')));

        return response()->json($result, isset($result['error']) ? 422 : 200);
    }

    /** @return array<string, mixed>|null */
    private function readDashboard(string $path): ?array
    {
        if ($path === '' || ! is_file($path) || ! is_readable($path)) {
            return null;
        }
        $contents = file_get_contents($path);
        $decoded = $contents === false ? null : json_decode($contents, true);

        return is_array($decoded) ? $decoded : null;
    }

    /** @param array<string, mixed> $dashboard
     *  @return array<string, mixed>
     */
    private function responseFor(array $dashboard, string $action): array
    {
        if ($action === 'menu') {
            return ['text' => $this->menuText($dashboard), 'keyboard' => $this->mainKeyboard()];
        }
        if (preg_match('/^period:(1|3|7|30)$/', $action, $matches) === 1) {
            $period = $dashboard['periods'][$matches[1]] ?? null;

            return [
                'text' => is_array($period)
                    ? (string) ($period['telegram_text'] ?? 'Данных за период нет.')
                    : 'Данных за период нет.',
                'keyboard' => $this->backKeyboard(),
            ];
        }
        if ($action === 'top10' || $action === 'not_found') {
            return ['text' => $this->positionList($dashboard, $action), 'keyboard' => $this->backKeyboard()];
        }
        if ($action === 'growth' || $action === 'drop') {
            return ['text' => $this->movementList($dashboard, $action), 'keyboard' => $this->backKeyboard()];
        }
        if ($action === 'analytics') {
            return ['text' => $this->analyticsText($dashboard), 'keyboard' => $this->backKeyboard()];
        }
        if (preg_match('/^keywords:(\d+)$/', $action, $matches) === 1) {
            return $this->keywordPage($dashboard, (int) $matches[1]);
        }
        if (preg_match('/^keyword:(\d+)$/', $action, $matches) === 1) {
            return $this->keywordDetail($dashboard, (int) $matches[1]);
        }
        if (preg_match('/^chart:(average|top10):(7|30|90)$/', $action, $matches) === 1) {
            return $this->chart($dashboard, $matches[1], (int) $matches[2]);
        }
        if ($action === 'refresh') {
            return [
                'text' => "🔄 Данные обновляются ежедневным безопасным импортом из Topvisor.\n\n".
                    'Платный запуск новой проверки позиций через API по этой кнопке отключён.',
                'keyboard' => $this->backKeyboard(),
            ];
        }

        return ['error' => 'Unknown action.', 'text' => 'Неизвестная команда.'];
    }

    /** @param array<string, mixed> $dashboard */
    private function menuText(array $dashboard): string
    {
        $labels = $dashboard['source_labels'] ?? [];
        $value = static fn (string $name): string => is_array($labels)
            ? (string) ($labels[$name] ?? 'нет данных') : 'нет данных';

        return implode("\n", [
            '🔎 SEO-мониторинг', '',
            'Контрольные позиции: Topvisor — '.$value('topvisor'),
            'Поисковая аналитика: Webmaster — '.$value('yandex_webmaster'),
            'Органика и конверсии: Metrika — '.$value('yandex_metrika'), '',
            'Дата позиции: '.(string) ($dashboard['anchor_date'] ?? 'нет данных'),
        ]);
    }

    /** @return array<int, array<int, array{text: string, callback_data: string}>> */
    private function mainKeyboard(): array
    {
        return [
            [['text' => '📅 Сегодня', 'callback_data' => 'seo:period:1']],
            [
                ['text' => '📅 3 дня', 'callback_data' => 'seo:period:3'],
                ['text' => '📅 7 дней', 'callback_data' => 'seo:period:7'],
                ['text' => '📅 30 дней', 'callback_data' => 'seo:period:30'],
            ],
            [
                ['text' => '🏆 TOP-10', 'callback_data' => 'seo:top10'],
                ['text' => '📈 Рост', 'callback_data' => 'seo:growth'],
                ['text' => '📉 Падение', 'callback_data' => 'seo:drop'],
            ],
            [
                ['text' => '❌ Не найдено', 'callback_data' => 'seo:not_found'],
                ['text' => '🔑 Запросы', 'callback_data' => 'seo:keywords:0'],
            ],
            [['text' => '📊 Webmaster + Metrika', 'callback_data' => 'seo:analytics']],
            [
                ['text' => '📈 Позиции 30 дней', 'callback_data' => 'seo:chart:average:30'],
                ['text' => '🏆 TOP-10 30 дней', 'callback_data' => 'seo:chart:top10:30'],
            ],
            [['text' => '🔄 Обновление', 'callback_data' => 'seo:refresh']],
        ];
    }

    /** @return array<int, array<int, array{text: string, callback_data: string}>> */
    private function backKeyboard(): array
    {
        return [[['text' => '⬅️ Назад', 'callback_data' => 'seo:menu']]];
    }

    /** @param array<string, mixed> $dashboard */
    private function positionList(array $dashboard, string $type): string
    {
        $rows = is_array($dashboard['keywords'] ?? null) ? $dashboard['keywords'] : [];
        $selected = array_values(array_filter($rows, static function (mixed $row) use ($type): bool {
            if (! is_array($row)) {
                return false;
            }

            return $type === 'top10'
                ? ($row['status'] ?? null) === 'found' && (int) ($row['position'] ?? 999) <= 10
                : ($row['status'] ?? null) === 'not_found';
        }));
        $title = $type === 'top10' ? '🏆 Запросы в TOP-10' : '❌ Не найдено в TOP-100';
        if ($selected === []) {
            return $title."\n\nНет запросов.";
        }
        $lines = [$title, ''];
        foreach (array_slice($selected, 0, 30) as $row) {
            $position = $row['position'] ?? '—';
            $frequency = array_key_exists('frequency', $row) && $row['frequency'] !== null
                ? ' · частота '.$row['frequency'] : '';
            $lines[] = $row['keyword'].' — '.$position.$frequency;
        }

        return implode("\n", $lines);
    }

    /** @param array<string, mixed> $dashboard */
    private function movementList(array $dashboard, string $type): string
    {
        $summary = $dashboard['periods']['7']['positions'] ?? [];
        $rows = $summary[$type === 'growth' ? 'best_growth' : 'worst_drop'] ?? [];
        $title = $type === 'growth' ? '📈 Рост за 7 дней' : '📉 Падение за 7 дней';
        if (! is_array($rows) || $rows === []) {
            return $title."\n\nНет сопоставимых изменений.";
        }
        $lines = [$title, ''];
        foreach (array_slice($rows, 0, 20) as $row) {
            $lines[] = sprintf(
                "%s\n%s → %s (%+.1f)",
                $row['keyword'], $row['before'], $row['current'], (float) ($row['change'] ?? 0),
            );
        }

        return implode("\n", $lines);
    }

    /** @param array<string, mixed> $dashboard */
    private function analyticsText(array $dashboard): string
    {
        $period = $dashboard['periods']['7'] ?? [];
        $webmaster = is_array($period['webmaster'] ?? null) ? $period['webmaster'] : [];
        $metrika = is_array($period['metrika'] ?? null) ? $period['metrika'] : [];
        $metric = static fn (array $row, string $key): string => array_key_exists($key, $row)
            && $row[$key] !== null ? (string) $row[$key] : 'нет данных';

        return implode("\n", [
            '📊 Фактическая аналитика за 7 дней', '', 'Webmaster:',
            'Показы: '.$metric($webmaster, 'shows'),
            'Клики: '.$metric($webmaster, 'clicks'),
            'CTR: '.$metric($webmaster, 'ctr'),
            'Новых запросов: '.(is_array($webmaster['new_queries'] ?? null)
                ? count($webmaster['new_queries']) : 'нет данных'), '',
            'Metrika — органика:',
            'Визиты: '.$metric($metrika, 'visits'),
            'Пользователи: '.$metric($metrika, 'users'),
            'Достижения целей: '.$metric($metrika, 'goal_reaches'),
            'Мессенджеры: '.$metric($metrika, 'messenger_reaches'), '',
            'Конверсии связываются только с landing page, не с конкретным запросом.',
        ]);
    }

    /** @param array<string, mixed> $dashboard
     *  @return array<string, mixed>
     */
    private function keywordPage(array $dashboard, int $offset): array
    {
        $keywords = array_values(is_array($dashboard['keywords'] ?? null) ? $dashboard['keywords'] : []);
        $offset = max(0, min($offset, max(count($keywords) - 1, 0)));
        $page = array_slice($keywords, $offset, 8);
        $keyboard = [];
        foreach ($page as $row) {
            if (! is_array($row)) {
                continue;
            }
            $position = ($row['status'] ?? null) === 'found' ? (string) $row['position'] : '—';
            $keyboard[] = [[
                'text' => $position.' · '.mb_strimwidth((string) $row['keyword'], 0, 42, '…'),
                'callback_data' => 'seo:keyword:'.(int) $row['keyword_id'],
            ]];
        }
        $navigation = [];
        if ($offset > 0) {
            $navigation[] = ['text' => '◀️', 'callback_data' => 'seo:keywords:'.max(0, $offset - 8)];
        }
        if ($offset + 8 < count($keywords)) {
            $navigation[] = ['text' => '▶️', 'callback_data' => 'seo:keywords:'.($offset + 8)];
        }
        if ($navigation !== []) {
            $keyboard[] = $navigation;
        }
        $keyboard[] = [['text' => '⬅️ Назад', 'callback_data' => 'seo:menu']];

        return [
            'text' => '🔑 Целевые запросы '.($offset + 1).'–'.min($offset + 8, count($keywords)).
                ' из '.count($keywords),
            'keyboard' => $keyboard,
        ];
    }

    /** @param array<string, mixed> $dashboard
     *  @return array<string, mixed>
     */
    private function keywordDetail(array $dashboard, int $keywordId): array
    {
        $history = $dashboard['keyword_histories'][(string) $keywordId] ?? null;
        if (! is_array($history)) {
            return ['error' => 'Unknown keyword.', 'text' => 'Запрос не найден.'];
        }
        $current = is_array($history['current'] ?? null) ? $history['current'] : [];
        $lines = ['🔑 '.(string) ($history['keyword'] ?? ''), '',
            'Сейчас: '.($current['position'] ?? 'не найдено')];
        foreach ([3, 7, 30] as $days) {
            $row = $history['periods'][(string) $days] ?? $history['periods'][$days] ?? null;
            $lines[] = $days.' дней: '.(is_array($row)
                ? (($row['position'] ?? 'не найдено').' · изменение '.($row['change'] ?? '—'))
                : 'нет измерения');
        }
        if (! empty($current['found_url'])) {
            $lines[] = '';
            $lines[] = 'URL: '.$current['found_url'];
        }

        return [
            'text' => implode("\n", $lines),
            'keyboard' => [
                [['text' => '⬅️ К списку', 'callback_data' => 'seo:keywords:0']],
                [['text' => '⬅️ В меню', 'callback_data' => 'seo:menu']],
            ],
        ];
    }

    /** @param array<string, mixed> $dashboard
     *  @return array<string, mixed>
     */
    private function chart(array $dashboard, string $kind, int $days): array
    {
        $key = $kind === 'average' ? 'average_position_'.$days.'d' : 'top10_count_'.$days.'d';
        $path = $dashboard['charts'][$key] ?? null;
        if (! is_string($path) || ! is_file($path) || ! is_readable($path)) {
            return [
                'text' => 'График пока недоступен: недостаточно данных или не установлен matplotlib.',
                'keyboard' => $this->backKeyboard(),
            ];
        }
        $contents = file_get_contents($path);
        if ($contents === false) {
            return ['error' => 'Chart read failed.', 'text' => 'Не удалось прочитать график.'];
        }

        return [
            'text' => $kind === 'average'
                ? '📈 Средняя позиция Topvisor — '.$days.' дней'
                : '🏆 Количество запросов в TOP-10 — '.$days.' дней',
            'photo_base64' => base64_encode($contents),
            'photo_filename' => basename($path),
            'keyboard' => $this->backKeyboard(),
        ];
    }
}
